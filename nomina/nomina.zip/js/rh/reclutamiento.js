let vm = new Vue({
    el: "#recruitment",
    data:{
        nombre: '',
        materno: '',
        paterno: '',
        nacimiento: '',
        curp:'',
        rfc: '',
        nss: '',
        tieneLicencia:"no",
        licencias: [],
        exp_laboral:[],
        exp_empresa: '',
        exp_puesto: '',
        exp_duracion: '',
        calle: '',
        ext: '',
        int: '',
        cp:'',
        colonia: '',
        ciudad: '',
        municipio: ''
    }, 
    methods: {
        register: function () {  
            
        }
    },
})