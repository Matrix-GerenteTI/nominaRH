<?php
define("HOST","localhost");
define("USER","sestrada");
define("PASSWORD","M@tr1x2017");
define("BD","dbnomina");
?>